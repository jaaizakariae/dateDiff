
import React from 'react';
import './App.css';

import DateDiffForm from './date-diff/DateDiffForm';

function App() {
  return (
    // import of DateDiffForm component
    <DateDiffForm />
  );
}

export default App;

